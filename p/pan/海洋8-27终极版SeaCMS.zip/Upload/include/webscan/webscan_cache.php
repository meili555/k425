<?php 
define('WEBSCAN_U_KEY', 'key');
define('WEBSCAN_API_LOG', 'http://127.0.0.1');
define('WEBSCAN_UPDATE_FILE','http://127.0.0.1');
$webscan_switch=1;
$webscan_post=1;
$webscan_get=1;
$webscan_cookie=1;
$webscan_referre=1;
$webscan_white_directory='';
$webscan_white_url = 
array();
?>