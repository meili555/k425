<?php 
$PLUS=array (
  'HideVideo' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '',
    ),
    'info' => '<center><font style="font-size:16px; color:#ccc;"><br><br>提示：该影片已下架！</font></center>',
  ),
  'JmpVideo' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '1',
    ),
  ),
  'Other' => 
  array (
    'numPerPage' => '20',
  ),
  'HideName' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '',
    ),
    'info' => '<center><font style="font-size:16px; color:#ccc;"><br><br>提示：该影片已下架！</font></center>',
  ),
  'HideType' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '',
    ),
    'info' => '<center><font style="font-size:16px; color:#ccc;"><br><br>提示：当前视频必须使用手机播放！</font></center>',
  ),
);
