<?php 
$cfg_mb_open = '0';
$cfg_mb_allowreg = '1';
$cfg_md_mailtest = '0';
$cfg_mb_idmin = '3';
$cfg_mb_pwdmin = '3';
$cfg_mb_pwdtype = '32';
$cfg_mb_rank = '10';
$cfg_mb_spacesta = '0';
$cfg_mb_notallow = 'www,bbs,ftp,mail,user,users,admin,administrator';
$cfg_max_face = '1024';
$cfg_online_type = 'nps';
$cfg_sendmail_bysmtp = '1';
$cfg_smtp_server = 'smtp.qq.com';
$cfg_smtp_port = '25';
$cfg_smtp_usermail = '';
$cfg_smtp_user = '';
$cfg_smtp_password = '';
?>