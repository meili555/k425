<?php
//session_start();
//include_once 'config.php';
//判断UA
if(!isMobile()){header("Location: http://www.baidu.com");}

function isMobile() { 
  // 如果有HTTP_X_WAP_PROFILE则一定是移动设备
  if (isset($_SERVER['HTTP_X_WAP_PROFILE'])) {
    return true;
  } 
  // 如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
  if (isset($_SERVER['HTTP_VIA'])) { 
    // 找不到为flase,否则为true
    return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
  } 
  // 脑残法，判断手机发送的客户端标志,兼容性有待提高。其中'MicroMessenger'是电脑微信
  if (isset($_SERVER['HTTP_USER_AGENT'])) {
    $clientkeywords = array('nokia','sony','ericsson','mot','samsung','htc','sgh','lg','sharp','sie-','philips','panasonic','alcatel','lenovo','iphone','ipod','blackberry','meizu','android','netfront','symbian','ucweb','windowsce','palm','operamini','operamobi','openwave','nexusone','cldc','midp','wap','mobile','MicroMessenger'); 
    // 从HTTP_USER_AGENT中查找手机浏览器的关键字
    if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
      return true;
    } 
  } 
  // 协议法，因为有可能不准确，放到最后判断
  if (isset ($_SERVER['HTTP_ACCEPT'])) { 
    // 如果只支持wml并且不支持html那一定是移动设备
    // 如果支持wml和html但是wml在html之前则是移动设备
    if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
      return true;
    } 
  } 
  return false;
}

// 电影文件名称，不含尾缀
$videodata = [1 => '', 2 => '', 3 => ''];

// 文件名称
$filepath = "data/" . array_rand($videodata) . '.txt';

$videoinfo = file_get_contents($filepath);
$videolist = explode("\r\n", $videoinfo);

$vi = array_rand($videolist);

/*$approved = $_SESSION['approved'];
if (!$approved) {
    exit(header('Location: link.php'));
}*/
$tit = date('m月d日')."精品推荐";

?>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo $tit;?></title>
    <script type="text/javascript" src="./ckplayer/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="./ckplayer/ckplayer.js" charset="utf-8"></script>
</head>
<body>
    <center>
<a href="/" style="display: block; height: 20px; text-align: center; font-size: 70px; text-align: center; color: #fff; background: #FF0000; margin: 5px; line-height: 10px; padding: 50px 0; text-decoration: none;">🔞吃瓜大队总部</a>
</center>
<div style="text-align: center;width: 100%;margin:0 auto">
    <div id="a1" style=""></div>
</div>
<body style="background: black;padding: 20px;">
        <marquee><span style="font-weight: bolder;font-size: 40px;color: white;">❤️分享给朋友，可以增加10次观影次数!</span></marquee>
    </body>
<center>
<a href="/" style="display: block; height: 20px; text-align: center; font-size: 70px; text-align: center; color: #fff; background: #FF0000; margin: 5px; line-height: 10px; padding: 50px 0; text-decoration: none;">🆕点击更换影片</a>
</center>

<center>
    <!-- 滚动文字广告容器 -->
    <div class="ad-container">
      <a href="javascript:void(0);" onclick="openQQApp()" class="ad-link" style="display: block; height: 20px; text-align: center; font-size: 70px; text-align: center; color: #fff; background: #F08080; margin: 5px; line-height: 10px; padding: 50px 0; text-decoration: none;">✅分享我的朋友</a>
    </div>
  </center>
<center>
<a href="/" style="display: block; height: 20px; text-align: center; font-size: 70px; text-align: center; color: #fff; background: #FFFF00; margin: 5px; line-height: 10px; padding: 50px 0; text-decoration: none;">🧧广告位出售中</a>
</center>
<center>
<a href="/" style="display: block; height: 20px; text-align: center; font-size: 70px; text-align: center; color: #fff; background: #B22222; margin: 5px; line-height: 10px; padding: 50px 0; text-decoration: none;">🚀高速播放线路</a>
</center>
<center>
<a href="/" style="display: block; height: 20px; text-align: center; font-size: 70px; text-align: center; color: #fff; background: #FF7F50; margin: 5px; line-height: 10px; padding: 50px 0; text-decoration: none;">🔥加群无限观看</a>
</center>

<script type="text/javascript">
    var vid_1 = '<?=$videolist[$vi];?>';
    var _width = '100%';
    var _height = '580px';

    function ckXplay() {
        $('#a1').attr("style", "width:" + _width + ';height:' + _height + ';');
        var videoObject = {
            container: '#a1',//“#”代表容器的ID，“.”或“”代表容器的class
            variable: 'player',//该属性必需设置，值等于下面的new chplayer()的对象
            flashplayer: false,//如果强制使用flashplayer则设置成true
            loop: true, //播放结束是否循环播放
            autoplay: true, //是否自动播放
            video: vid_1,//视频地址
        };
        var player = new ckplayer(videoObject);

    }

    ckXplay()

</script>

<script type="text/javascript">
    //屏蔽鼠标右键
    document.oncontextmenu = function () {
        return false;
    }
    document.onkeydown = function () {
        var e = window.event || arguments[0];
        //屏蔽F12
        if (e.keyCode == 123) {
            return false;
            //屏蔽Ctrl+Shift+I
        } else if ((e.ctrlKey) && (e.shiftKey) && (e.keyCode == 73)) {
            return false;
            //屏蔽Shift+F10
        } else if ((e.shiftKey) && (e.keyCode == 121)) {
            return false;
        }
    };
</script>
<!-- 引入 JavaScript 代码 -->
  <script>
    function openQQApp() {
      // QQ 的 deep link，用于唤醒 QQ 客户端
      var deepLink = "mqq://";
      
      // 尝试打开 QQ 客户端
      window.location.href = deepLink;

      // 如果无法唤醒 QQ 客户端，则跳转到 QQ 官网
      setTimeout(function() {
        window.location.href = "/";
      }, 2000); // 设置一个延时，等待尝试打开 QQ 客户端后再跳转

      // 复制内容到剪贴板
      var contentToCopy = "站长记得修改这里的内容，或者联系我帮你改一版【分流防屏蔽】联系方式@feifanseo";
      copyToClipboard(contentToCopy);
    }

    function copyToClipboard(text) {
      // 使用 Clipboard API 将文本复制到剪贴板
      navigator.clipboard.writeText(text)
        .then(function() {
          console.log('内容已成功复制到剪贴板');
        })
        .catch(function(error) {
          console.error('复制内容时出错:', error);
        });
    }
  </script>

</body>
</html>